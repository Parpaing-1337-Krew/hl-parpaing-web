#define		ICE	1

class CIceParpaing : public CParpaing
{
public:
	void Spawn();
	void SecondaryAttack();
};