				HALF-LIFE PARPAING : HTTP://WWW.HL-PARPAING.FR.ST
						     HTTP://HLP.PMAD.NET


HL-Parpaing est un mod culturel.
Vous l'aurez remarqu�.

Le projet est parti d'un d�lire d'une personne isol�e sur un forum, s'est propag� sur IRC, puis a conquis les esprits de nombreux fans, des gens ont boss� dessus (ou ont essay�), et le voil�.
Enfin. Apr�s plusieurs ann�es de pr�paration m�ticuleuse.
Devant vos yeux pleins de mouillassure due � la vue prolong�e de votre �cran.

Une remarque importante (tr�s) :
Half-Life Parpaing peut choquer, nous le concevons.
Nous montrons une image peu s�rieuse, voire grossi�re, de ma�ons, parfois �trangers, ce qui pourrait laisser faire croire � du racisme.
Tout cela n'est que parodie, caricature, exg�ration; loin de nous l'intention de nous moquer de quelque population.
Aucun de nous n'est assez stupide pour �tre raciste.
Half-Life Parpaing est aussi x�nophobe qu'une blague belge, c'est � dire nullement.


Bugs connus :
- Plantage d'hl.exe quand les musiques sont activ�es et qu'Half-Life est quitt� par "exit" ou trop rapidement par le menu.
- Tremblement de la vue pendant le KO.
- Le mode d�veloppeur est obligatoire pour voir les models d'HLP en solo et en thirdperson, mais cela ne concerne en rien le jeu multijoueurs.
- Quand une map est lanc�e via la console, un sprite d'HL est affich� au-dessus d'une barre de progression. Encore une fois, cela ne concerne en rien le jeu multijoueurs.
- Le parpaing peut se mettre � "danser" quand il est lanc� sur une surface, dans certaines conditions. Ce probl�me est d� au moteur d'Half-Life, et n'emp�che pas de reprendre le parpaing.


Merci �
--
- Shadow pour son FTP qui nous aura bien servi
- Aguiran, pareil
- Tous les musiciens qu'on a �cout� pendant le faisage du mod : Trent Reznor, Alec Empire, Richard D. James, Chris Vrenna, Sean Booth & Rob Brown, Tom Jenkinson, Fr�d�ric Mercy, Mathieu Gollain...
- Diverses personnes qui ont parl� de nous sur un forum ou un chan IRC, permettant au mod de gagner des fans avant m�me sa sortie.
- Damien pour le sifflet qu'il a emprunt� � sa prof de sport
- mik AKA kurim, pour son merveilleux codage du mur et d'autres joyeuset�s